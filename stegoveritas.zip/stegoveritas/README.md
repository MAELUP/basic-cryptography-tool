sudo apt install python3-pip

sudo pip3 install stegoveritas

sudo stegoveritas crypto4-stegoveritas-secret_image.png

sudo stegoveritas file
