install: https://github.com/ReFirmLabs/binwalk/wiki/Quick-Start-Guide

mkdir ./output

sudo binwalk --run-as=root -e --directory=./output -D 'jpg image:jpg' crypto5-binwalk.jp
