install: https://github.com/fabienpe/MP3Stego

decode -X -P p@ssw0rd svega_stego.mp3
